# I-01 course recovery report — partial

Intended main population: 20 independent worlds; known paired outcomes: 0/20. Physical new attempts: 18/500; historical 45 recorded separately.

Clear-minus-retain mean: None; unknown bounds: [-1.0, 1.0]. Correct-prefix descriptive denominator: 0; unknown prefixes: 20.

This is a controlled recovery extension of SILO-BENCH I-01. Clearing removes remote information in prior messages. Small sample and one seed/prefix per world limit inference; zero-width intervals do not establish equivalence. Principal effort is ready-model recovery inference time. Costs of unsuccessful episodes are spending, not useful efficiency. Loading, observed allocation and unknown provider time are separate. Shared prefix is physically charged once and logically to both policies. No native benchmark, pure anchoring, correction-specific, broad generalization or superiority claim follows.

Review every trace using the frozen rubric; human labels require call references. Ambiguous mechanisms remain ambiguous. Save the executed notebook separately and download the latest portable archive off session.

```json
{
  "status": "partial",
  "intended_worlds": 20,
  "known_pairs": 0,
  "paired_counts": {
    "unknown": 20
  },
  "clear_minus_retain": null,
  "complete_case_descriptive_mean": null,
  "missingness_bounds": [
    -1.0,
    1.0
  ],
  "interval": null,
  "correct_prefix_denominator": 0,
  "unknown_prefixes": 20,
  "correct_prefix_interval": null,
  "correct_prefix_mean": null,
  "attempts": 18,
  "contingency": 0,
  "hard_limit": 500,
  "historical_attempts_separate": 45,
  "in_flight": 0,
  "gates": {
    "selfcheck": {
      "checks": [
        "native fixture 827/revised 780; duplicates/negative/boundary",
        "fixed strata/seeds; private views; finality/wait; literal siblings; invalid actions",
        "raw-before-effects; idempotence; pre-persistence retry; 499/500; backup/ZIP/expanded restore; unknown vs zero"
      ],
      "environment": "scripted temporary DBs; no model loaded",
      "executed_at": "2026-10-15T09:44:25.143277+00:00",
      "model_attempts": 0,
      "native_tokenizer": true,
      "passed": true,
      "tokenizer": {
        "conservative_input_bound": 6885,
        "framing": "native exact template; no truncation",
        "input_limit": 8192,
        "resident_direct": 8704,
        "resident_thinking": 12288,
        "template": "{%- set image_count = namespace(value=0) %}\n{%- set video_count = namespace(value=0) %}\n{%- macro render_content(content, do_vision_count, is_system_content=false) %}\n    {%- if content is string %}\n        {{- content }}\n    {%- elif content is iterable and content is not mapping %}\n        {%- for item in content %}\n            {%- if 'image' in item or 'image_url' in item or item.type == 'image' %}\n                {%- if is_system_content %}\n                    {{- raise_exception('System message cannot contain images.') }}\n                {%- endif %}\n                {%- if do_vision_count %}\n                    {%- set image_count.value = image_count.value + 1 %}\n                {%- endif %}\n                {%- if add_vision_id %}\n                    {{- 'Picture ' ~ image_count.value ~ ': ' }}\n                {%- endif %}\n                {{- '<|vision_start|><|image_pad|><|vision_end|>' }}\n            {%- elif 'video' in item or item.type == 'video' %}\n                {%- if is_system_content %}\n                    {{- raise_exception('System message cannot contain videos.') }}\n                {%- endif %}\n                {%- if do_vision_count %}\n                    {%- set video_count.value = video_count.value + 1 %}\n                {%- endif %}\n                {%- if add_vision_id %}\n                    {{- 'Video ' ~ video_count.value ~ ': ' }}\n                {%- endif %}\n                {{- '<|vision_start|><|video_pad|><|vision_end|>' }}\n            {%- elif 'text' in item %}\n                {{- item.text }}\n            {%- else %}\n                {{- raise_exception('Unexpected item type in content.') }}\n            {%- endif %}\n        {%- endfor %}\n    {%- elif content is none or content is undefined %}\n        {{- '' }}\n    {%- else %}\n        {{- raise_exception('Unexpected content type.') }}\n    {%- endif %}\n{%- endmacro %}\n{%- if not messages %}\n    {{- raise_exception('No messages provided.') }}\n{%- endif %}\n{%- if tools and tools is iterable and tools is not mapping %}\n    {{- '<|im_start|>system\\n' }}\n    {{- \"# Tools\\n\\nYou have access to the following functions:\\n\\n<tools>\" }}\n    {%- for tool in tools %}\n        {{- \"\\n\" }}\n        {{- tool | tojson }}\n    {%- endfor %}\n    {{- \"\\n</tools>\" }}\n    {{- '\\n\\nIf you choose to call a function ONLY reply in the following format with NO suffix:\\n\\n<tool_call>\\n<function=example_function_name>\\n<parameter=example_parameter_1>\\nvalue_1\\n</parameter>\\n<parameter=example_parameter_2>\\nThis is the value for the second parameter\\nthat can span\\nmultiple lines\\n</parameter>\\n</function>\\n</tool_call>\\n\\n<IMPORTANT>\\nReminder:\\n- Function calls MUST follow the specified format: an inner <function=...></function> block must be nested within <tool_call></tool_call> XML tags\\n- Required parameters MUST be specified\\n- You may provide optional reasoning for your function call in natural language BEFORE the function call, but NOT after\\n- If there is no function call available, answer the question like normal with your current knowledge and do not tell the user about function calls\\n</IMPORTANT>' }}\n    {%- if messages[0].role == 'system' %}\n        {%- set content = render_content(messages[0].content, false, true)|trim %}\n        {%- if content %}\n            {{- '\\n\\n' + content }}\n        {%- endif %}\n    {%- endif %}\n    {{- '<|im_end|>\\n' }}\n{%- else %}\n    {%- if messages[0].role == 'system' %}\n        {%- set content = render_content(messages[0].content, false, true)|trim %}\n        {{- '<|im_start|>system\\n' + content + '<|im_end|>\\n' }}\n    {%- endif %}\n{%- endif %}\n{%- set ns = namespace(multi_step_tool=true, last_query_index=messages|length - 1) %}\n{%- for message in messages[::-1] %}\n    {%- set index = (messages|length - 1) - loop.index0 %}\n    {%- if ns.multi_step_tool and message.role == \"user\" %}\n        {%- set content = render_content(message.content, false)|trim %}\n        {%- if not(content.startswith('<tool_response>') and content.endswith('</tool_response>')) %}\n            {%- set ns.multi_step_tool = false %}\n            {%- set ns.last_query_index = index %}\n        {%- endif %}\n    {%- endif %}\n{%- endfor %}\n{%- if ns.multi_step_tool %}\n    {{- raise_exception('No user query found in messages.') }}\n{%- endif %}\n{%- for message in messages %}\n    {%- set content = render_content(message.content, true)|trim %}\n    {%- if message.role == \"system\" %}\n        {%- if not loop.first %}\n            {{- raise_exception('System message must be at the beginning.') }}\n        {%- endif %}\n    {%- elif message.role == \"user\" %}\n        {{- '<|im_start|>' + message.role + '\\n' + content + '<|im_end|>' + '\\n' }}\n    {%- elif message.role == \"assistant\" %}\n        {%- set reasoning_content = '' %}\n        {%- if message.reasoning_content is string %}\n            {%- set reasoning_content = message.reasoning_content %}\n        {%- else %}\n            {%- if '</think>' in content %}\n                {%- set reasoning_content = content.split('</think>')[0].rstrip('\\n').split('<think>')[-1].lstrip('\\n') %}\n                {%- set content = content.split('</think>')[-1].lstrip('\\n') %}\n            {%- endif %}\n        {%- endif %}\n        {%- set reasoning_content = reasoning_content|trim %}\n        {%- if loop.index0 > ns.last_query_index %}\n            {{- '<|im_start|>' + message.role + '\\n<think>\\n' + reasoning_content + '\\n</think>\\n\\n' + content }}\n        {%- else %}\n            {{- '<|im_start|>' + message.role + '\\n' + content }}\n        {%- endif %}\n        {%- if message.tool_calls and message.tool_calls is iterable and message.tool_calls is not mapping %}\n            {%- for tool_call in message.tool_calls %}\n                {%- if tool_call.function is defined %}\n                    {%- set tool_call = tool_call.function %}\n                {%- endif %}\n                {%- if loop.first %}\n                    {%- if content|trim %}\n                        {{- '\\n\\n<tool_call>\\n<function=' + tool_call.name + '>\\n' }}\n                    {%- else %}\n                        {{- '<tool_call>\\n<function=' + tool_call.name + '>\\n' }}\n                    {%- endif %}\n                {%- else %}\n                    {{- '\\n<tool_call>\\n<function=' + tool_call.name + '>\\n' }}\n                {%- endif %}\n                {%- if tool_call.arguments is defined %}\n                    {%- for args_name, args_value in tool_call.arguments|items %}\n                        {{- '<parameter=' + args_name + '>\\n' }}\n                        {%- set args_value = args_value | tojson | safe if args_value is mapping or (args_value is sequence and args_value is not string) else args_value | string %}\n                        {{- args_value }}\n                        {{- '\\n</parameter>\\n' }}\n                    {%- endfor %}\n                {%- endif %}\n                {{- '</function>\\n</tool_call>' }}\n            {%- endfor %}\n        {%- endif %}\n        {{- '<|im_end|>\\n' }}\n    {%- elif message.role == \"tool\" %}\n        {%- if loop.previtem and loop.previtem.role != \"tool\" %}\n            {{- '<|im_start|>user' }}\n        {%- endif %}\n        {{- '\\n<tool_response>\\n' }}\n        {{- content }}\n        {{- '\\n</tool_response>' }}\n        {%- if not loop.last and loop.nextitem.role != \"tool\" %}\n            {{- '<|im_end|>\\n' }}\n        {%- elif loop.last %}\n            {{- '<|im_end|>\\n' }}\n        {%- endif %}\n    {%- else %}\n        {{- raise_exception('Unexpected message role.') }}\n    {%- endif %}\n{%- endfor %}\n{%- if add_generation_prompt %}\n    {{- '<|im_start|>assistant\\n' }}\n    {%- if enable_thinking is defined and enable_thinking is false %}\n        {{- '<think>\\n\\n</think>\\n\\n' }}\n    {%- else %}\n        {{- '<think>\\n' }}\n    {%- endif %}\n{%- endif %}"
      }
    },
    "window": {
      "deadline": "2026-10-15T21:27:17.689021+00:00",
      "evidence": "Kaggle shows 12 hours remaining in this session; available GPU allowance covers those 12 hours.",
      "observed_start": "2026-10-15T09:47:17.699644+00:00",
      "session": "1b2059eb-50e3-4952-b658-b13357130b8f"
    },
    "resident_load": "1b2059eb-50e3-4952-b658-b13357130b8f/load-0",
    "loaded_session": "1b2059eb-50e3-4952-b658-b13357130b8f",
    "readiness": {
      "ABA_equal": [
        true,
        true
      ],
      "equality_policy": "Diagnostic: unexpected differences require explicit state-isolation review before qualification; no extra samples or decoding changes.",
      "needs_review": false,
      "passed": true,
      "results": [
        {
          "label": "A1",
          "outcome": {
            "backend": {
              "allocated_bytes": 7685424128,
              "cache": {
                "calls": 14,
                "disposed_after_call": true,
                "initial_empty": true,
                "same_call_cache": true
              },
              "cpu_seed": 2895223694339253810,
              "cuda_seed": 2895223694339253810,
              "device": "cuda:0",
              "finite_score_steps": 14,
              "free_bytes_with_cache": 7603027968,
              "memory_samples": 74,
              "observed_free_min_bytes": 7603027968,
              "observed_peak_free_lower_bytes": 7603027968,
              "peak_reserved_bytes": 7889485824,
              "pid": 394,
              "raw_suffix_text": "{\"message\":null,\"submit\":3,\"wait\":false}<|im_end|>",
              "removed_terminal_id": 248046,
              "reserved_bytes": 7889485824,
              "seed": 2895223694339253810,
              "total_bytes": 15636037632
            },
            "dispatch_seconds": 3.904117172999918,
            "failure": null,
            "framing_error": null,
            "generated_tokens": 14,
            "input_tokens": 67,
            "peak_memory_bytes": 7793119744,
            "raw_text": "{\"message\":null,\"submit\":3,\"wait\":false}",
            "ready_seconds": 3.8648043120000466,
            "termination": "eos",
            "thinking": null,
            "token_ids": [
              4754,
              1927,
              763,
              2827,
              1288,
              5769,
              763,
              18,
              1288,
              11158,
              763,
              3721,
              92,
              248046
            ],
            "truncated": false,
            "visible_text": "{\"message\":null,\"submit\":3,\"wait\":false}"
          },
          "slot": 0
        },
        {
          "label": "B",
          "outcome": {
            "backend": {
              "allocated_bytes": 7685555200,
              "cache": {
                "calls": 16,
                "disposed_after_call": true,
                "initial_empty": true,
                "same_call_cache": true
              },
              "cpu_seed": 1172835993072093706,
              "cuda_seed": 1172835993072093706,
              "device": "cuda:0",
              "finite_score_steps": 16,
              "free_bytes_with_cache": 7603027968,
              "memory_samples": 46,
              "observed_free_min_bytes": 7603027968,
              "observed_peak_free_lower_bytes": 7603027968,
              "peak_reserved_bytes": 7889485824,
              "pid": 394,
              "raw_suffix_text": "{\"message\":null,\"submit\":100,\"wait\":false}<|im_end|>",
              "removed_terminal_id": 248046,
              "reserved_bytes": 7889485824,
              "seed": 1172835993072093706,
              "total_bytes": 15636037632
            },
            "dispatch_seconds": 2.2792206469999883,
            "failure": null,
            "framing_error": null,
            "generated_tokens": 16,
            "input_tokens": 69,
            "peak_memory_bytes": 7793251840,
            "raw_text": "{\"message\":null,\"submit\":100,\"wait\":false}",
            "ready_seconds": 2.2763378979999516,
            "termination": "eos",
            "thinking": null,
            "token_ids": [
              4754,
              1927,
              763,
              2827,
              1288,
              5769,
              763,
              16,
              15,
              15,
              1288,
              11158,
              763,
              3721,
              92,
              248046
            ],
            "truncated": false,
            "visible_text": "{\"message\":null,\"submit\":100,\"wait\":false}"
          },
          "slot": 0
        },
        {
          "label": "A2",
          "outcome": {
            "backend": {
              "allocated_bytes": 7685424128,
              "cache": {
                "calls": 14,
                "disposed_after_call": true,
                "initial_empty": true,
                "same_call_cache": true
              },
              "cpu_seed": 2895223694339253810,
              "cuda_seed": 2895223694339253810,
              "device": "cuda:0",
              "finite_score_steps": 14,
              "free_bytes_with_cache": 7603027968,
              "memory_samples": 34,
              "observed_free_min_bytes": 7603027968,
              "observed_peak_free_lower_bytes": 7603027968,
              "peak_reserved_bytes": 7889485824,
              "pid": 394,
              "raw_suffix_text": "{\"message\":null,\"submit\":3,\"wait\":false}<|im_end|>",
              "removed_terminal_id": 248046,
              "reserved_bytes": 7889485824,
              "seed": 2895223694339253810,
              "total_bytes": 15636037632
            },
            "dispatch_seconds": 1.7040395149999767,
            "failure": null,
            "framing_error": null,
            "generated_tokens": 14,
            "input_tokens": 67,
            "peak_memory_bytes": 7793119744,
            "raw_text": "{\"message\":null,\"submit\":3,\"wait\":false}",
            "ready_seconds": 1.7014791929999546,
            "termination": "eos",
            "thinking": null,
            "token_ids": [
              4754,
              1927,
              763,
              2827,
              1288,
              5769,
              763,
              18,
              1288,
              11158,
              763,
              3721,
              92,
              248046
            ],
            "truncated": false,
            "visible_text": "{\"message\":null,\"submit\":3,\"wait\":false}"
          },
          "slot": 0
        },
        {
          "label": "A1",
          "outcome": {
            "backend": {
              "allocated_bytes": 7685424128,
              "cache": {
                "calls": 14,
                "disposed_after_call": true,
                "initial_empty": true,
                "same_call_cache": true
              },
              "cpu_seed": 9113091594724103221,
              "cuda_seed": 9113091594724103221,
              "device": "cuda:0",
              "finite_score_steps": 14,
              "free_bytes_with_cache": 7603027968,
              "memory_samples": 57,
              "observed_free_min_bytes": 7603027968,
              "observed_peak_free_lower_bytes": 7603027968,
              "peak_reserved_bytes": 7889485824,
              "pid": 409,
              "raw_suffix_text": "{\"message\":null,\"submit\":3,\"wait\":false}<|im_end|>",
              "removed_terminal_id": 248046,
              "reserved_bytes": 7889485824,
              "seed": 9113091594724103221,
              "total_bytes": 15636037632
            },
            "dispatch_seconds": 2.9618398540000044,
            "failure": null,
            "framing_error": null,
            "generated_tokens": 14,
            "input_tokens": 67,
            "peak_memory_bytes": 7793119744,
            "raw_text": "{\"message\":null,\"submit\":3,\"wait\":false}",
            "ready_seconds": 2.9219616889999998,
            "termination": "eos",
            "thinking": null,
            "token_ids": [
              4754,
              1927,
              763,
              2827,
              1288,
              5769,
              763,
              18,
              1288,
              11158,
              763,
              3721,
              92,
              248046
            ],
            "truncated": false,
            "visible_text": "{\"message\":null,\"submit\":3,\"wait\":false}"
          },
          "slot": 1
        },
        {
          "label": "B",
          "outcome": {
            "backend": {
              "allocated_bytes": 7685555200,
              "cache": {
                "calls": 16,
                "disposed_after_call": true,
                "initial_empty": true,
                "same_call_cache": true
              },
              "cpu_seed": 718885271260442133,
              "cuda_seed": 718885271260442133,
              "device": "cuda:0",
              "finite_score_steps": 16,
              "free_bytes_with_cache": 7603027968,
              "memory_samples": 45,
              "observed_free_min_bytes": 7603027968,
              "observed_peak_free_lower_bytes": 7603027968,
              "peak_reserved_bytes": 7889485824,
              "pid": 409,
              "raw_suffix_text": "{\"message\":null,\"submit\":100,\"wait\":false}<|im_end|>",
              "removed_terminal_id": 248046,
              "reserved_bytes": 7889485824,
              "seed": 718885271260442133,
              "total_bytes": 15636037632
            },
            "dispatch_seconds": 2.2600111909999896,
            "failure": null,
            "framing_error": null,
            "generated_tokens": 16,
            "input_tokens": 69,
            "peak_memory_bytes": 7793251840,
            "raw_text": "{\"message\":null,\"submit\":100,\"wait\":false}",
            "ready_seconds": 2.257483801000035,
            "termination": "eos",
            "thinking": null,
            "token_ids": [
              4754,
              1927,
              763,
              2827,
              1288,
              5769,
              763,
              16,
              15,
              15,
              1288,
              11158,
              763,
              3721,
              92,
              248046
            ],
            "truncated": false,
            "visible_text": "{\"message\":null,\"submit\":100,\"wait\":false}"
          },
          "slot": 1
        },
        {
          "label": "A2",
          "outcome": {
            "backend": {
              "allocated_bytes": 7685424128,
              "cache": {
                "calls": 14,
                "disposed_after_call": true,
                "initial_empty": true,
                "same_call_cache": true
              },
              "cpu_seed": 9113091594724103221,
              "cuda_seed": 9113091594724103221,
              "device": "cuda:0",
              "finite_score_steps": 14,
              "free_bytes_with_cache": 7603027968,
              "memory_samples": 36,
              "observed_free_min_bytes": 7603027968,
              "observed_peak_free_lower_bytes": 7603027968,
              "peak_reserved_bytes": 7889485824,
              "pid": 409,
              "raw_suffix_text": "{\"message\":null,\"submit\":3,\"wait\":false}<|im_end|>",
              "removed_terminal_id": 248046,
              "reserved_bytes": 7889485824,
              "seed": 9113091594724103221,
              "total_bytes": 15636037632
            },
            "dispatch_seconds": 1.7909419729999172,
            "failure": null,
            "framing_error": null,
            "generated_tokens": 14,
            "input_tokens": 67,
            "peak_memory_bytes": 7793119744,
            "raw_text": "{\"message\":null,\"submit\":3,\"wait\":false}",
            "ready_seconds": 1.7887443159999066,
            "termination": "eos",
            "thinking": null,
            "token_ids": [
              4754,
              1927,
              763,
              2827,
              1288,
              5769,
              763,
              18,
              1288,
              11158,
              763,
              3721,
              92,
              248046
            ],
            "truncated": false,
            "visible_text": "{\"message\":null,\"submit\":3,\"wait\":false}"
          },
          "slot": 1
        }
      ]
    },
    "active_generation": false,
    "screen/direct": {
      "correct": 10,
      "passed": false,
      "protocol_errors": 0,
      "reason": "",
      "total": 12
    },
    "operator_authorization": {
      "action": "snapshot",
      "args": {
        "boundary": "operator-error-screen"
      },
      "evidence": "Explicit operator finite-action command/button"
    },
    "action": {
      "args": {
        "boundary": "operator-error-screen"
      },
      "at": "2026-10-15T09:50:07.182758+00:00",
      "error": null,
      "name": "snapshot",
      "status": "complete"
    }
  },
  "terminal_reasons": {
    "control_completed": 12
  },
  "lost_spending": {
    "upper": 0,
    "resolved": true
  },
  "physical_ready_seconds_observed": 42.238601042999676,
  "physical_dispatch_seconds_observed": 42.36453037499996,
  "attempts_unknown_ready_seconds": 0,
  "generated_tokens_observed": 281,
  "attempts_unknown_generated_tokens": 0,
  "model_load_seconds_observed": 116.99611570799993,
  "failed_model_load_seconds_observed": 0,
  "provider_assignment_release": "unknown unless supplied separately; observation and process exit do not establish allocation boundaries",
  "principal_effort_clear_minus_retain_seconds": null,
  "principal_effort_interval": null,
  "cost_complete_pairs": 0
}
```
