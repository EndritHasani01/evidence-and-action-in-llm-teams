"""Worker-local raw calls and pre-delivery inputs (spec §9).

Checkpoints, owned by runner.py, are the sole delivery/peer-state authority.
These ordinary SQLite transactions never span inference or use saver internals.
One worker serially owns a file; process bounds belong to attempts.py.
"""

from dataclasses import asdict, dataclass
from datetime import datetime, timezone
import json
from math import isfinite
from pathlib import Path
import os
import sqlite3

from .manifests import _branch
from .prompts import COURSE_LIMITS, RenderedRequest, TokenizedRequest, limits_from_settings
from .protocol import GeneratedReply
from .replay import SavedRound
from .rounds import RoundRequests, deserialize_state, snapshot_bytes, validate_round
from .state import Slot


def record_json(value) -> str:
    return json.dumps(value, sort_keys=True, ensure_ascii=True, allow_nan=False,
                      separators=(",", ":"))


def settings_json(settings: dict) -> str:
    if type(settings) is not dict:
        raise ValueError("generation settings must be a complete JSON object")
    return record_json(settings)


def connect(path: Path, *, readonly=False) -> sqlite3.Connection:
    location = Path(path).resolve().as_uri() + "?mode=ro" if readonly else str(path)
    connection = sqlite3.connect(location, uri=readonly, check_same_thread=False, timeout=30)
    try:
        connection.row_factory = sqlite3.Row
        if readonly:
            connection.execute("PRAGMA query_only=ON")
        else:
            connection.execute("PRAGMA journal_mode=WAL")
            connection.execute("PRAGMA synchronous=FULL")
        connection.execute("PRAGMA foreign_keys=ON")
        if (connection.execute("PRAGMA journal_mode").fetchone()[0] != "wal"
                or not readonly and connection.execute("PRAGMA synchronous").fetchone()[0] != 2):
            raise ValueError("worker database requires on-disk WAL/FULL durability")
    except BaseException:
        connection.close()
        raise
    return connection


@dataclass(frozen=True, slots=True)
class RecordedFailure:
    """Final known outcome, never a missing/unexecuted call or retry request.

    Attempt termination and exhaustion are established by the process controller.
    Detail remains host-only.
    """

    status: str
    reason: str

    def __post_init__(self):
        if (type(self.status) is not str or self.status not in ("timeout", "infrastructure_failure")
                or type(self.reason) is not str or not self.reason):
            raise ValueError("record a timeout or exhausted infrastructure failure")


class UnresolvedAttempt(RuntimeError):
    """No durable response: establish worker interruption before any retry."""


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def seconds(value: float) -> float:
    if type(value) not in (int, float) or not isfinite(value) or value < 0:
        raise ValueError("timing must be finite and nonnegative")
    return float(value)


class WorkerStore:
    def __init__(self, path: Path, *, readonly=False, parents=()):
        self.path = Path(path).resolve()
        self.parents = tuple(parents)
        self.connection = connect(self.path, readonly=readonly)
        if readonly:
            self._read_run_inputs()
            return
        self.connection.executescript("""
            CREATE TABLE IF NOT EXISTS round_inputs (
                branch_id TEXT NOT NULL, round_number INTEGER NOT NULL,
                branch_json TEXT NOT NULL, settings_json TEXT NOT NULL,
                requests_json TEXT NOT NULL,
                PRIMARY KEY (branch_id, round_number)
            );
            CREATE TABLE IF NOT EXISTS calls (
                call_id TEXT PRIMARY KEY, branch_id TEXT NOT NULL,
                round_number INTEGER NOT NULL, peer INTEGER NOT NULL,
                seed INTEGER NOT NULL, generation_id TEXT NOT NULL,
                replay_parent TEXT,
                status TEXT NOT NULL CHECK (status IN
                    ('pending','running','completed','timeout','infrastructure_failure','replay')),
                raw_json TEXT, failure_json TEXT, validation_json TEXT,
                FOREIGN KEY (branch_id, round_number)
                    REFERENCES round_inputs(branch_id, round_number),
                CHECK (NOT (raw_json IS NOT NULL AND failure_json IS NOT NULL))
            );
            CREATE TABLE IF NOT EXISTS attempts (
                call_id TEXT NOT NULL REFERENCES calls(call_id),
                number INTEGER NOT NULL CHECK (number BETWEEN 1 AND 2),
                status TEXT NOT NULL, started_at TEXT NOT NULL,
                finished_at TEXT, elapsed_seconds REAL,
                uncertain_completion INTEGER NOT NULL DEFAULT 0,
                PRIMARY KEY (call_id, number)
            );
            CREATE TABLE IF NOT EXISTS provider_processes (
                call_id TEXT NOT NULL, number INTEGER NOT NULL,
                pid INTEGER NOT NULL, started_at TEXT NOT NULL,
                ready_at TEXT, last_observed_at TEXT NOT NULL,
                stopped_at TEXT, recovered_at TEXT, termination_reason TEXT,
                uncertain_stop INTEGER NOT NULL DEFAULT 0,
                PRIMARY KEY (call_id, number),
                FOREIGN KEY (call_id, number) REFERENCES attempts(call_id, number)
            );
            CREATE TABLE IF NOT EXISTS run_inputs (
                singleton INTEGER PRIMARY KEY CHECK (singleton=1), inputs_json TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS allocations (
                number INTEGER PRIMARY KEY, device TEXT NOT NULL,
                stage TEXT NOT NULL, started_at TEXT NOT NULL, stopped_at TEXT,
                deadline_at TEXT, budget_json TEXT, billing_json TEXT,
                stop_reason TEXT
            );
        """)
        # Reopen T01 worker files without replacing their calls/checkpoints.
        columns = {r[1] for r in self.connection.execute("PRAGMA table_info(attempts)")}
        with self.connection:
            call_columns = {r[1] for r in self.connection.execute("PRAGMA table_info(calls)")}
            if "request_tokens" not in call_columns:
                self.connection.execute("ALTER TABLE calls ADD COLUMN request_tokens INTEGER")
                # One exclusive-owner migration of existing resource metadata.
                # Status never migrates or reads complete archived token arrays.
                self.connection.execute("""UPDATE calls SET request_tokens=(
                    SELECT json_array_length(requests_json, CASE WHEN calls.peer=-1
                        THEN '$.tokenized.input_ids'
                        ELSE '$.tokenized[' || calls.peer || '].input_ids' END)
                    FROM round_inputs WHERE branch_id=calls.branch_id AND round_number=calls.round_number)""")
            for name, definition in (
                ("timeout_seconds", "REAL"), ("termination_seconds", "REAL"),
                ("observed_seconds", "REAL NOT NULL DEFAULT 0"),
                ("termination_reason", "TEXT"), ("reason", "TEXT"),
                ("recovered_at", "TEXT"), ("worker_pid", "INTEGER"),
                ("peak_memory_bytes", "INTEGER"),
                ("backend_json", "TEXT"),
            ):
                if name not in columns:
                    self.connection.execute(f"ALTER TABLE attempts ADD COLUMN {name} {definition}")
            process_columns = {r[1] for r in self.connection.execute("PRAGMA table_info(provider_processes)")}
            if "device_visibility" not in process_columns:
                self.connection.execute("ALTER TABLE provider_processes ADD COLUMN device_visibility TEXT")
            if "backend_json" not in process_columns:
                self.connection.execute("ALTER TABLE provider_processes ADD COLUMN backend_json TEXT")
        self._read_run_inputs()

    def _read_run_inputs(self):
        # Older standalone round files need no migration to remain readable.
        exists = self.connection.execute("SELECT 1 FROM sqlite_master WHERE name='run_inputs'").fetchone()
        row = self.connection.execute("SELECT inputs_json FROM run_inputs WHERE singleton=1").fetchone() if exists else None
        self.run_inputs = json.loads(row[0]) if row else None

    def close(self):
        self.connection.close()

    def bind_run(self, worlds, branches, settings, bounds, *, budget=None, regime="thesis"):
        """Reject restart input drift before admitting any new scheduled work.

        The same literal run inputs bind each worker file; placement/order are
        operational choices and do not change these scientific inputs.
        """
        from .populations import _check_regime
        _check_regime(regime)
        if budget is not None:
            from .accounting import CourseBudget
            if (regime == "course") != isinstance(budget, CourseBudget):
                raise ValueError("course bindings require CourseBudget; thesis retains its budget representation")
        if regime == "course":
            from .inference import QWEN_4B, QWEN_9B
            from .prompts import prompt_profile, COMPACT_PROFILE
            accepted_models = {(QWEN_4B.model,QWEN_4B.revision)}
            if prompt_profile(settings) == COMPACT_PROFILE:
                accepted_models.add((QWEN_9B.model,QWEN_9B.revision))
            if (limits_from_settings(settings) != COURSE_LIMITS
                    or (settings.get("model"), settings.get("revision")) not in accepted_models
                    or settings.get("generation", {}).get("max_new_tokens") != COURSE_LIMITS.output_tokens):
                raise ValueError("course workers require explicit course limits and an adopted pinned candidate")
        inputs = {"worlds": [asdict(w) for w in sorted(worlds, key=lambda w: w.world_id)],
            "branches": [asdict(b) for b in sorted(branches, key=lambda b: b.branch_id)],
            "settings": json.loads(settings_json(settings)), "bounds": bounds}
        if regime == "course":
            inputs["regime"] = regime  # Old thesis bindings retain their exact representation.
        if budget is not None:
            inputs["budget"] = asdict(budget)
        payload = record_json(inputs)
        with self.connection:
            previous = self.connection.execute("SELECT inputs_json FROM run_inputs WHERE singleton=1").fetchone()
            if previous is not None and previous[0] != payload:
                raise ValueError("worker run inputs/settings/attempt bounds differ; resume the saved configuration")
            self.connection.execute("INSERT OR IGNORE INTO run_inputs VALUES (1,?)", (payload,))
        self._read_run_inputs()

    def check_run(self, world, branch, settings):
        """Check supplied inputs against the existing worker binding, if present."""
        if self.run_inputs is not None:
            worlds = {w["world_id"]: w for w in self.run_inputs["worlds"]}
            branches = {_branch(b).branch_id: b for b in self.run_inputs["branches"]}
            if (record_json(worlds.get(world.world_id)) != record_json(asdict(world))
                    or record_json(branches.get(branch.branch_id)) != record_json(asdict(branch))
                    or settings_json(self.run_inputs["settings"]) != settings_json(settings)):
                raise ValueError("worker input/settings/schedule differ from the saved configuration")

    def assert_parent_scope(self, parent, *, required=False):
        """Course parents must belong to the same literal run, regardless of IDs."""
        course = any(s.run_inputs is not None and s.run_inputs.get("regime", "thesis") == "course"
                     for s in (self, parent))
        if (required or course) and (self.run_inputs is None or parent.run_inputs is None
                                    or self.run_inputs != parent.run_inputs):
            raise ValueError("foreign or unbound worker bundle/configuration cannot supply a course parent")

    def allocation_started(self, device, stage, *, budget=None, deadline_at=None,
                           billing=None, started_at=None):
        """Record explicitly allocated devices, including time without a model.

        Only the exclusive owner may write. A process exit is not a provider
        release; leave the interval open until release is acknowledged.
        """
        if type(device) is not str or not device or stage not in ("development", "main", "validation"):
            raise ValueError("record an identified device and allocation stage")
        started_at = started_at or utc_now()
        start = datetime.fromisoformat(started_at)
        deadline = datetime.fromisoformat(deadline_at) if deadline_at else None
        if start.tzinfo is None or deadline and (deadline.tzinfo is None or deadline <= start):
            raise ValueError("allocation requires zoned, increasing clocks")
        with self.connection:
            if self.connection.execute("SELECT 1 FROM allocations WHERE stopped_at IS NULL").fetchone():
                raise ValueError("preceding allocation has no confirmed release")
            cursor = self.connection.execute("""INSERT INTO allocations
                (device,stage,started_at,deadline_at,budget_json,billing_json)
                VALUES (?,?,?,?,?,?)""", (device, stage, started_at, deadline_at,
                record_json(asdict(budget)) if budget is not None else None,
                record_json(billing) if billing is not None else None))
            return cursor.lastrowid

    def allocation_stopped(self, number, reason, *, released_at=None):
        with self.connection:
            row = self.connection.execute("SELECT * FROM allocations WHERE number=?", (number,)).fetchone()
            if row is None:
                raise ValueError("missing allocation")
            if row["stopped_at"] is None:
                released_at = released_at or utc_now()
                release = datetime.fromisoformat(released_at)
                if release.tzinfo is None or release < datetime.fromisoformat(row["started_at"]):
                    raise ValueError("release requires a zoned clock after allocation start")
                self.connection.execute("UPDATE allocations SET stopped_at=?,stop_reason=? WHERE number=?",
                    (released_at, reason, number))

    def allocation_stop_requested(self, number, reason):
        with self.connection:
            self.connection.execute("UPDATE allocations SET stop_reason=? WHERE number=? AND stopped_at IS NULL",
                                    (reason, number))

    def allocation_observation_ended(self, number, *, at, reason):
        """End a measured notebook interval without claiming GPU deallocation."""
        row = self.connection.execute("SELECT * FROM allocations WHERE number=?", (number,)).fetchone()
        if row is None:
            raise ValueError("missing allocation observation")
        if row["stopped_at"] is not None:
            return
        end = datetime.fromisoformat(at)
        if end.tzinfo is None or end < datetime.fromisoformat(row["started_at"]):
            raise ValueError("observation end precedes its start")
        billing = json.loads(row["billing_json"] or "{}")
        billing.update(provider_release_confirmed=False,measurement_scope="observed_notebook_interval",
            unobserved_provider_time="unknown",segment_end="observation_end")
        with self.connection:
            self.connection.execute("UPDATE allocations SET stopped_at=?,stop_reason=?,billing_json=? WHERE number=?",
                (at,reason,record_json(billing),number))

    def allocation_transferred(self, number, successor, *, at):
        """End one accounting segment while the same provider assignment continues.

        The successor's already-persisted open segment must start at this exact
        boundary. This records a stage change, never provider deallocation.
        """
        row = self.connection.execute("SELECT * FROM allocations WHERE number=?", (number,)).fetchone()
        if row is None or row["stopped_at"] is not None:
            raise ValueError("transfer requires the original open allocation")
        billing = json.loads(row["billing_json"] or "{}")
        next_billing = json.loads(successor["billing_json"] or "{}")
        if (successor["stopped_at"] is not None or successor["started_at"] != at
                or successor["device"] != row["device"]
                or not billing.get("provider_assignment_at")
                or any(billing.get(k) != next_billing.get(k) for k in
                       ("provider", "provider_assignment_at", "physical_gpu_uuid"))
                or datetime.fromisoformat(at) < datetime.fromisoformat(row["started_at"])):
            raise ValueError("transfer must preserve the physical assignment without a gap")
        billing.update(provider_release_confirmed=False, segment_end="stage_transfer",
                       successor_stage=successor["stage"])
        with self.connection:
            self.connection.execute("UPDATE allocations SET stopped_at=?,stop_reason=?,billing_json=? WHERE number=?",
                (at, "stage transfer; same provider assignment remains chargeable", record_json(billing), number))

    def _record(self, table, where, values):
        # Table/predicate are internal constants, never user-supplied SQL.
        matches = []
        for store in (self, *self.parents):
            row = store.connection.execute(f"SELECT * FROM {table} WHERE {where}", values).fetchone()
            if row is not None:
                if store is not self:
                    self.assert_parent_scope(store)
                matches.append((store, dict(row)))
        if len(matches) != 1:
            raise ValueError(f"{'missing' if not matches else 'duplicate'} saved {table} identity: {values}")
        return matches[0]

    def prepare(self, branch, settings: str, requests: RoundRequests):
        """Save the frozen barrier and all pending slots in one transaction."""
        r = requests.slot.round_number
        payload = record_json({
            "before": snapshot_bytes(requests.before).decode("utf-8"),
            "slot": asdict(requests.slot),
            "rendered": [asdict(v) for v in requests.rendered],
            "tokenized": [asdict(v) for v in requests.tokenized],
        })
        identity = record_json(asdict(branch))
        calls = tuple(c for c in branch.calls if c.round_number == r)
        with self.connection:
            previous = self.connection.execute(
                "SELECT * FROM round_inputs WHERE branch_id=? AND round_number=?",
                (branch.branch_id, r)).fetchone()
            if previous is not None:
                if (previous["branch_json"], previous["settings_json"], previous["requests_json"]) != (
                        identity, settings, payload):
                    raise ValueError("saved round request/settings/branch equality failed")
                for call in calls:
                    row = self.call(call.call_id)
                    expected = (branch.branch_id, r, call.peer, call.seed,
                                call.generation_id, call.replay_parent)
                    if tuple(row[k] for k in ("branch_id", "round_number", "peer", "seed",
                                              "generation_id", "replay_parent")) != expected:
                        raise ValueError("saved call identity differs from scheduled slot")
                    if row["request_tokens"] != len(requests.tokenized[call.peer].input_ids):
                        raise ValueError("saved request token count differs from exact inputs")
                return
            self.connection.execute("INSERT INTO round_inputs VALUES (?,?,?,?,?)",
                                    (branch.branch_id, r, identity, settings, payload))
            for call in calls:
                self.connection.execute("""INSERT INTO calls
                    (call_id,branch_id,round_number,peer,seed,generation_id,replay_parent,status,request_tokens)
                    VALUES (?,?,?,?,?,?,?,'pending',?)""",
                    (call.call_id, branch.branch_id, r, call.peer, call.seed,
                     call.generation_id, call.replay_parent, len(requests.tokenized[call.peer].input_ids)))

    def call(self, call_id: str) -> dict:
        return self._record("calls", "call_id=?", (call_id,))[1]

    def response(self, call_id: str) -> GeneratedReply | RecordedFailure:
        row = self.call(call_id)
        if row["replay_parent"] is not None:
            if row["status"] != "replay":
                raise ValueError("logical replay has not been obtained")
            row = self.call(row["generation_id"])
            if row["replay_parent"] is not None:
                raise ValueError("replay parent must be an original physical generation")
        if row["status"] == "completed" and row["raw_json"] is not None:
            raw = json.loads(row["raw_json"])
            return GeneratedReply(**dict(raw, token_ids=tuple(raw["token_ids"])))
        if row["status"] in ("timeout", "infrastructure_failure") and row["failure_json"] is not None:
            return RecordedFailure(**json.loads(row["failure_json"]))
        raise ValueError("call has no durable completed response/failure")

    def attempts(self, call_id: str) -> tuple[dict, ...]:
        store, _ = self._record("calls", "call_id=?", (call_id,))
        return tuple(dict(r) for r in store.connection.execute(
            "SELECT * FROM attempts WHERE call_id=? ORDER BY number", (call_id,)))

    def prepare_control(self, branch, settings, view, rendered, tokenized):
        """Save one isolated request: a control or a development smoke probe.

        Smoke uses the same call/attempt tables, with its actual peer and a
        separate smoke branch; it is never relabelled as a scheduled control.
        """
        if (branch.phase not in ("control", "smoke") or len(branch.calls) != 1
                or branch.calls[0].round_number != 1 or branch.calls[0].replay_parent is not None
                or branch.calls[0].peer != view.peer or branch.task != view.task):
            raise ValueError("one isolated non-replay control/smoke request required")
        call = branch.calls[0]
        peer = -1 if call.peer is None else call.peer
        payload = record_json({"view": asdict(view), "rendered": asdict(rendered), "tokenized": asdict(tokenized)})
        identity = record_json(asdict(branch))
        with self.connection:
            row = self.connection.execute("SELECT * FROM round_inputs WHERE branch_id=? AND round_number=1",
                                          (branch.branch_id,)).fetchone()
            if row is not None:
                if (row["branch_json"], row["settings_json"], row["requests_json"]) != (identity, settings, payload):
                    raise ValueError("saved control request/settings/branch equality failed")
                saved = self.call(call.call_id)
                if tuple(saved[k] for k in ("branch_id", "round_number", "peer", "seed", "generation_id", "replay_parent")) != (
                        branch.branch_id, 1, peer, call.seed, call.generation_id, None):
                    raise ValueError("saved control slot identity differs")
                if saved["request_tokens"] != len(tokenized.input_ids):
                    raise ValueError("saved control request token count differs")
                return
            self.connection.execute("INSERT INTO round_inputs VALUES (?,1,?,?,?)",
                                    (branch.branch_id, identity, settings, payload))
            self.connection.execute("""INSERT INTO calls
                (call_id,branch_id,round_number,peer,seed,generation_id,status,request_tokens)
                VALUES (?, ?,1,?,?,?,'pending',?)""", (call.call_id, branch.branch_id, peer, call.seed, call.generation_id, len(tokenized.input_ids)))

    def save_control_validation(self, call_id, reply):
        raw = self.response(call_id)
        if reply.generated != (raw if type(raw) is GeneratedReply else None):
            raise ValueError("control validation differs from durable outcome")
        encoded = record_json(asdict(reply))
        with self.connection:
            row = self.call(call_id)
            if row["validation_json"] is not None and row["validation_json"] != encoded:
                raise ValueError("control validation differs from recorded outcome")
            self.connection.execute("UPDATE calls SET validation_json=? WHERE call_id=?", (encoded, call_id))

    def begin_attempt(self, call_id: str, *, timeout_seconds=None, termination_seconds=None) -> int:
        for value in (timeout_seconds, termination_seconds):
            if value is not None and seconds(value) == 0:
                raise ValueError("attempt and termination bounds must be positive")
        with self.connection:
            if self._record("calls", "call_id=?", (call_id,))[0] is not self:
                raise ValueError("only the original worker can attempt its physical call")
            row = self.call(call_id)
            if row["replay_parent"] is not None:
                raise ValueError("a replay cannot start physical inference")
            if row["status"] == "running":
                raise UnresolvedAttempt(f"unresolved attempt without a durable reply: {call_id}")
            if row["status"] != "pending":
                raise ValueError("only a pending physical call can start an attempt")
            previous = self.attempts(call_id)
            if previous and (len(previous) != 1 or previous[0]["status"] != "interrupted"):
                raise UnresolvedAttempt("only one established infrastructure interruption permits a retry")
            if previous and (previous[0]["timeout_seconds"], previous[0]["termination_seconds"]) != (
                    timeout_seconds, termination_seconds):
                raise ValueError("identical-request retry requires the original attempt bounds")
            number = len(previous) + 1
            self.connection.execute("""INSERT INTO attempts
                (call_id,number,status,started_at,timeout_seconds,termination_seconds)
                VALUES (?,?,'running',?,?,?)""",
                (call_id, number, utc_now(), timeout_seconds, termination_seconds))
            self.connection.execute("UPDATE calls SET status='running' WHERE call_id=?", (call_id,))
            return number

    def finish_attempt(self, call_id: str, response, elapsed_seconds: float, *, termination_reason=None,
                       peak_memory_bytes=None, backend=None):
        elapsed_seconds = seconds(elapsed_seconds)
        if backend is not None and type(backend) is not dict:
            raise ValueError("backend evidence must be a JSON object or unavailable")
        backend_json = None if backend is None else record_json(backend)
        if peak_memory_bytes is not None and (type(peak_memory_bytes) is not int or peak_memory_bytes < 0):
            raise ValueError("peak memory is measured nonnegative bytes or unavailable")
        if response is None:
            response = RecordedFailure("infrastructure_failure", "provider recorded an exhausted failed slot")
        if type(response) not in (GeneratedReply, RecordedFailure):
            raise ValueError("provider must return exact generated output or a recorded failure")
        raw = record_json(asdict(response)) if type(response) is GeneratedReply else None
        failure = record_json(asdict(response)) if type(response) is RecordedFailure else None
        status = "completed" if raw is not None else response.status
        with self.connection:
            row = self.call(call_id)
            if row["status"] != "running":
                raise ValueError("response commit requires its active attempt")
            attempt = self.attempts(call_id)[-1]
            if attempt["status"] != "running":
                raise UnresolvedAttempt("a blocked attempt cannot commit an inferred outcome")
            self.connection.execute("UPDATE calls SET status=?,raw_json=?,failure_json=? WHERE call_id=?",
                                    (status, raw, failure, call_id))
            self.connection.execute("""UPDATE attempts SET status=?,finished_at=?,elapsed_seconds=?,
                observed_seconds=?,termination_reason=?,reason=?,peak_memory_bytes=?,backend_json=?
                WHERE call_id=? AND number=?""",
                (status, utc_now(), elapsed_seconds, elapsed_seconds,
                 termination_reason or (response.termination if raw is not None else response.status),
                 response.reason if failure is not None else None, peak_memory_bytes, backend_json,
                 call_id, attempt["number"]))

    def interrupt_attempt(self, call_id: str, reason: str, *, elapsed_seconds=None,
                          termination_reason="worker_interruption"):
        """Only an absent durable outcome can authorize the single retry.

        After owner death, end time/duration are unknown. Keep observed work and
        recovery time separately; neither lost work nor its ambiguity is erased.
        """
        if type(reason) is not str or not reason:
            raise ValueError("interruption requires a concrete host-only reason")
        if elapsed_seconds is not None:
            elapsed_seconds = seconds(elapsed_seconds)
        with self.connection:
            row = self.call(call_id)
            if row["status"] in ("completed", "timeout", "infrastructure_failure", "replay"):
                return  # A durable outcome always wins, including a timeout.
            if row["status"] != "running":
                raise ValueError("interruption requires a running attempt")
            attempt = self.attempts(call_id)[-1]
            if attempt["status"] != "running":
                raise UnresolvedAttempt("diagnosed provider/protocol defects require repair, not retry")
            self.connection.execute("""UPDATE attempts SET status='interrupted',finished_at=?,
                elapsed_seconds=?,observed_seconds=MAX(observed_seconds,?),uncertain_completion=1,
                termination_reason=?,reason=?,recovered_at=? WHERE call_id=? AND number=?""",
                (utc_now() if elapsed_seconds is not None else None, elapsed_seconds,
                 elapsed_seconds or 0, termination_reason, reason,
                 utc_now() if elapsed_seconds is None else None, call_id, attempt["number"]))
            self.connection.execute("""UPDATE provider_processes SET uncertain_stop=1,
                recovered_at=?,termination_reason=? WHERE stopped_at IS NULL
                AND recovered_at IS NULL""", (utc_now(), termination_reason))
            if attempt["number"] == 2:
                failure = RecordedFailure("infrastructure_failure", "two infrastructure attempts interrupted: " + reason)
                self.connection.execute("UPDATE calls SET status=?,failure_json=? WHERE call_id=?",
                                        (failure.status, record_json(asdict(failure)), call_id))
            else:
                self.connection.execute("UPDATE calls SET status='pending' WHERE call_id=?", (call_id,))

    def block_attempt(self, call_id: str, reason: str, elapsed_seconds: float):
        """A diagnosed adapter/protocol defect stops; it is not a new sample."""
        with self.connection:
            attempt = self.attempts(call_id)[-1]
            if self.call(call_id)["status"] != "running" or attempt["status"] != "running":
                raise UnresolvedAttempt("defect requires its active attempt")
            self.connection.execute("""UPDATE attempts SET status='blocked',finished_at=?,
                elapsed_seconds=?,reason=?,termination_reason='provider_defect',uncertain_completion=1
                WHERE call_id=? AND number=?""",
                (utc_now(), seconds(elapsed_seconds), reason, call_id, attempt["number"]))

    def confirm_timeout_termination(self, call_id: str, elapsed_seconds: float):
        with self.connection:
            self.connection.execute("""UPDATE attempts SET elapsed_seconds=?,observed_seconds=?,
                finished_at=?,termination_reason='attempt_timeout' WHERE call_id=?
                AND status='timeout' AND termination_reason='timeout_termination_pending'""",
                (seconds(elapsed_seconds), seconds(elapsed_seconds), utc_now(), call_id))

    def recover_processes(self):
        """A new exclusive owner preserves unobserved prior process stop times."""
        with self.connection:
            self.connection.execute("""UPDATE provider_processes SET uncertain_stop=1,
                recovered_at=?,termination_reason='owner_interruption' WHERE stopped_at IS NULL
                AND recovered_at IS NULL""", (utc_now(),))

    def process_started(self, call_id: str, number: int, pid: int):
        now = utc_now()
        with self.connection:
            self.connection.execute("""INSERT INTO provider_processes
                (call_id,number,pid,started_at,last_observed_at,device_visibility) VALUES (?,?,?,?,?,?)""",
                (call_id, number, pid, now, now, os.environ.get("CUDA_VISIBLE_DEVICES")))

    def process_ready(self, call_id: str, number: int, *, backend=None):
        if backend is not None and type(backend) is not dict:
            raise ValueError("loading evidence must be a JSON object or unavailable")
        with self.connection:
            self.connection.execute("""UPDATE provider_processes SET ready_at=?,backend_json=?
                WHERE call_id=? AND number=?""",
                (utc_now(), None if backend is None else record_json(backend), call_id, number))

    def observe_attempt(self, call_id: str, number: int, elapsed_seconds: float, pid: int):
        with self.connection:
            self.connection.execute("UPDATE attempts SET observed_seconds=?,worker_pid=? WHERE call_id=? AND number=? AND status='running'",
                                    (seconds(elapsed_seconds), pid, call_id, number))
            self.connection.execute("UPDATE provider_processes SET last_observed_at=? WHERE pid=? AND stopped_at IS NULL AND recovered_at IS NULL",
                                    (utc_now(), pid))

    def process_stopped(self, call_id: str, number: int, reason: str):
        with self.connection:
            self.connection.execute("""UPDATE provider_processes SET stopped_at=?,termination_reason=?
                WHERE call_id=? AND number=? AND stopped_at IS NULL""", (utc_now(), reason, call_id, number))

    def inputs(self, branch_id: str, round_number: int):
        _, row = self._record("round_inputs", "branch_id=? AND round_number=?", (branch_id, round_number))
        branch = _branch(json.loads(row["branch_json"]))
        if branch.branch_id != branch_id:
            raise ValueError("saved barrier branch identity differs")
        calls = tuple(c for c in branch.calls if c.round_number == round_number)
        if len(calls) != 4 or tuple(c.peer for c in calls) != (0, 1, 2, 3):
            raise ValueError("saved barrier requires four ordered scheduled slots")
        for call in calls:
            saved_call = self.call(call.call_id)
            if tuple(saved_call[k] for k in ("branch_id", "round_number", "peer", "seed",
                                              "generation_id", "replay_parent")) != (
                    branch_id, round_number, call.peer, call.seed, call.generation_id, call.replay_parent):
                raise ValueError("saved call identity/seed/replay parent differs")
        data = json.loads(row["requests_json"])
        before = deserialize_state(data["before"].encode("utf-8"))
        slot = Slot(**data["slot"])
        if before.branch_id != branch_id or slot != before.next_slot or slot.round_number != round_number:
            raise ValueError("saved barrier differs from its pre-delivery state")
        views = tuple(p.view(before.task, before.size, i, slot, before.manifest)
                      for i, p in enumerate(before.peers))
        requests = RoundRequests(before, slot, views,
            tuple(RenderedRequest(**v) for v in data["rendered"]),
            tuple(TokenizedRequest(v["text"], tuple(v["input_ids"]), tuple(v["attention_mask"]))
                  for v in data["tokenized"]))
        for call in calls:
            if self.call(call.call_id)["request_tokens"] != len(requests.tokenized[call.peer].input_ids):
                raise ValueError("saved request token count differs from exact inputs")
        return branch, row["settings_json"], requests

    def save_validation(self, branch, barrier):
        """Save deterministic outcomes only after every raw reply is durable."""
        calls = tuple(c for c in branch.calls if c.round_number == barrier.requests.slot.round_number)
        with self.connection:
            for call, reply in zip(calls, barrier.replies):
                row = self.call(call.call_id)
                if call.replay_parent is not None:
                    parent = self.response(call.replay_parent)
                    raw = parent if type(parent) is GeneratedReply else None
                    if reply.generated != raw:
                        raise ValueError("replay outcome differs from its durable generation")
                    if row["status"] not in ("pending", "replay"):
                        raise ValueError("replay slot acquired a physical attempt")
                    self.connection.execute("UPDATE calls SET status='replay' WHERE call_id=?", (call.call_id,))
                raw = self.response(call.call_id)
                if reply.generated != (raw if type(raw) is GeneratedReply else None):
                    raise ValueError("validation differs from the durable raw outcome")
                encoded = record_json(asdict(reply))
                if row["validation_json"] is not None and row["validation_json"] != encoded:
                    raise ValueError("saved validation outcome equality failed")
                self.connection.execute("UPDATE calls SET validation_json=? WHERE call_id=?", (encoded, call.call_id))

    def saved_round(self, branch_id: str, round_number: int, tokenizer) -> SavedRound:
        branch, settings, requests = self.inputs(branch_id, round_number)
        calls = tuple(c for c in branch.calls if c.round_number == round_number)
        generated = []
        for call in calls:
            row = self.call(call.call_id)
            if row["validation_json"] is None:
                raise ValueError("missing saved validation for pre-delivery parent")
            response = self.response(call.call_id)
            generated.append(response if type(response) is GeneratedReply else None)
        barrier = validate_round(requests, tuple(generated), tokenizer,
                                  limits=limits_from_settings(json.loads(settings)))
        for call, reply in zip(calls, barrier.replies):
            if self.call(call.call_id)["validation_json"] != record_json(asdict(reply)):
                raise ValueError("replayed validation differs from the recorded parent outcome")
        return SavedRound(branch, settings, barrier)

    def backup(self, destination: Path):
        destination = Path(destination).resolve()
        # Exclusive creation protects an existing experiment archive.
        with destination.open("xb"):
            pass
        target = sqlite3.connect(destination)
        try:
            self.connection.backup(target)
        finally:
            target.close()
