# Synthetic CPU report validation

These are scripted CPU protocol/analysis fixtures, not model capability or
empirical findings. Original M3 workers in `tests/fixtures/scripted_lifecycle_run.zip`
remain authoritative. This derived bundle contains five portable read-only reports.
Open a linked report locally; each includes cases, literal traces, all M4 tables,
original input selection, fixed settings, plotting data, SVG and PNG exhibits.

| Scope | Recorded / scheduled | Unknown | Open report |
|---|---:|---:|---|
| complete-fallback | 2170 / 2170 | 0 | [Report](complete-fallback/report.html) |
| complete-target | 2170 / 2170 | 0 | [Report](complete-target/report.html) |
| incomplete-fallback-40 | 2170 / 12560 | 10390 | [Report](incomplete-fallback-40/report.html) |
| incomplete-target-60 | 2170 / 17656 | 15486 | [Report](incomplete-target-60/report.html) |
| stopped-prefix | 0 / 16 | 16 | [Report](stopped-prefix/report.html) |

Complete fixtures cover five families, every intervention/control and scheduled
repeat at each size. Incomplete scopes preserve the entire frozen 60/40 main
population. The stopped prefix preserves unknown scheduled slots. Case eligibility
does not alter any estimand population. Missing histories, empty preservation
populations and unobserved costs remain unavailable. Every report and figure is
labeled synthetic CPU validation.

Accounting clock: 2026-10-06T00:00:00+00:00. World bootstrap: 10,000 draws,
seed 20261006, fixed family seeds and type-7 quantiles; exact settings and
generation records are in report.json. Plotting environment is recorded separately
in figures/environment.json and does not freeze inference. N is observed/eligible
for world intervals and recorded/scheduled for capability-control outcomes.

Reproduce all sixteen original-worker scopes twice with:
`python -m tests.report_archive --export NEW_DIRECTORY` from the source checkout.
Render from saved plotting data with:
`python -m recovery.figures --report NEW_DIRECTORY/complete-target` (optional
Matplotlib report extra). Every output destination must be new.

The retained fixtures and named CPU coverage/category audit are described in
tests/fixtures/README.md and docs/validation/m4-cpu-gate.md in the repository.
GPU memory, loading, state/RNG independence, finite outputs, capability, accepted
host persistence and measured complete-schedule allocation remain M5 gates.
No pilot, main experiment or publication has occurred.
