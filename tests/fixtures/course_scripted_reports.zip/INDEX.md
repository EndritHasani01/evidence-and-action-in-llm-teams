# Course synthetic CPU reports

Derived from the unchanged course_lifecycle_run.zip; no model or GPU was run.
The report tables archive retains eight scopes. Five portable scopes are included:

- complete-selected-scope: all 2,170 supplied validation uses recorded, including
  270 invalid and 135 failed uses. This selected five-world scope is not the
  completed 20-world experiment.
- incomplete-main-20: 2,170 recorded/4,110 unknown out of 6,280 intended uses.
- stopped-prefix: all sixteen safely stopped uses unknown.
- unexecuted-development: all 1,178 development uses unknown.
- terminal-feasibility: synthetic documented terminal-failure example, not an
  actual model/GPU failure. All 6,280 main uses unknown; no accepted main freeze.

Every folder includes report/cases/calls HTML, exact traces and input selection,
all scientific tables, world contrasts/interval CSVs, deterministic plotting
inputs and seven SVG/PNG exhibit pairs. Open report.html locally. The five
reports retain unavailable values, full populations and literal call/message
IDs; cases are selected on replicate zero by the existing frozen rule.

Accounting clock: 2026-10-11T23:59:59+00:00. Bootstrap seed: 20261011.
The original scripted word counter supplies synthetic history counts, not
native Qwen tokens. CLI analysis without a matching tokenizer keeps these
nonempty history counts unavailable. Plotting uses Matplotlib 3.11.0/Agg and
DejaVu Sans; figures/environment.json is not a model environment freeze.

Reconstruct from the original workers with:
  python -m tests.course_report_archive --export NEW_DIRECTORY --figures
The reconstruction compares every prerequisite scientific join and every
report/export byte twice. Fresh export/figure destinations are required.

The 20-world course regime remains exploratory: four worlds per family, eight
in focal cohorts, five conditional repeats. 10,000 resamples add no independent
worlds or achieved power. GPU/runtime/capability/resources/freeze/main execution
and external delivery remain separate gates; this bundle supplies CPU evidence.
